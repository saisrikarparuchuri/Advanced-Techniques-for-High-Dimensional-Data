README
--------
Members of the team: 
- Jiayu Gao
- Saisrikar Paruchuri
- Roshan Bagla
- Leopold Fournier
- Chuan Leong Foo 

You just have to run the code to make it work, however take note that all the files to be input needs to 
be in the same folder as the code
	- The first file to be input is the data points file
	- The second file to be input is the query range file
	- The third file to be input is the nearest neighbor file
	
The format of each file strictly follows the specifications stated in the assignment sheet.

We declare that each member has done 20% of the work.