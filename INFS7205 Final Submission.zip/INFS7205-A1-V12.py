"""
Created on Thurs Apr 27 19:18 2017
@Group Members: Chuan Leong Foo, Leopold Fournier, Jiayu Gao, Saisrikar Paruchuri, Roshan Bagla
@PythonVersion: Python 3.5 32bit
"""
import math, time
from operator import itemgetter
from random import *
"""
Data Structure of a data point: array [id,x-coordinate,y-coordinate]
"""
class MBR:
    """
    This class represents an MBR (i.e a rectangle with axes parallel to the horizontal and vertical axes)
    """
    def __init__(self,x1=0,x2=0,y1=0,y2=0):
        """
        x1 is the lower x-coordinate of the MBR, x2 the higher x-coordinate.
        y1 is the lower y-coordinate of the MBR, y2 the higher x-coordinate.
        """
        self.x1=x1
        self.y1=y1
        self.x2=x2
        self.y2=y2
        if self.x1>self.x2 or self.y1>self.y2:
            print("Error in the definition of the rectangle!")
    
    def perimeter(self):
        """
        Calculate the perimeter of the rectangle.
        """
        return (2*(self.x2-self.x1) + 2*(self.y2-self.y1))
    
    def contains(self,p):
        """
        Return true if the MBR contains the point p, false otherwise.
        """
        return not (p[1]>self.x2 or p[1]<self.x1 or p[2]>self.y2 or p[2]<self.y1)
    
    def intersects(self,r):
        """
        Return true if the MBR intersects the rectangle r, false otherwise.
        Uses the function line_intersect, that takes as inputs 2 lines parallel and on the same axix and returns True if they intersect.
        The maths prove that if the 2 MBRs intersect if and only if their x-vertices, brought to the same axis, intersect, AND their x-vertices, brought to the same axis, intersect.
        This function is used for the query range.
        """
        return (self.line_intersect(self.x1,self.x2,r.x1,r.x2) and self.line_intersect(self.y1,self.y2,r.y1,r.y2) )

    def line_intersect(self,a1,a2,b1,b2):
        """
        Returns True if [a1,a2] and [b1,b2] intersect, False otherwise.
        """
        return ((a1<=b2 and a1>=b1) or (a2<=b2 and a2>=b1) or (a1<b1 and a2>b2))

    def show(self):
        """
        Just displays information about the MBR, used to test the code only.
        """
        return ('x1=', self.x1, 'x2=', self.x2, 'y1=', self.y1, 'y2=', self.y2)
    

def create_MBR_from_data_points(listDataPoints):
    """
    Creates, from a list of data points, the smallest MBR that contains all thoses points.
    """
    #Takes as input a list of data points and return the MBR containing those points.
    #A data point is considered as a list such as: [id,x,y]
    list_x=[]
    list_y=[]
    for dataPoint in listDataPoints:
        list_x+=[dataPoint[1]]
        list_y+=[dataPoint[2]]
    The_MBR=MBR(x1=min(list_x),x2=max(list_x),y1=min(list_y),y2=max(list_y))
    return The_MBR


def create_MBR_from_MBRs(listMBR):
    """
    Creates, from a list of MBRs, the smallest MBR that contains all thoses points.
    """
    #Takes as input a list of MBRs and return the MBR containing those points.
    #A data point is considered as a list such as: [id,x,y]
    list_x1=[]
    list_x2=[]
    list_y1=[]
    list_y2=[]
    for MBR0 in listMBR:
        list_x1+=[MBR0.x1]
        list_x2+=[MBR0.x2]
        list_y1+=[MBR0.y1]
        list_y2+=[MBR0.y2]
    The_MBR=MBR(x1=min(list_x1),x2=max(list_x2),y1=min(list_y1),y2=max(list_y2))
    return The_MBR

class RTree:
    """
    An RTree is a collection of "Node" objects. A requirement that it must
    contain a rootNode.
    
    B is defined at the creation of the R tree. By default, we take B=3.
    #reating a Rtree automatically create its Root node.
    """
    def __init__(self, B=3):
        self.rootNode = Node()
        self.B = B

    def insert(self,u,p):
        """
        u is a object of type Node and p is a dataPoint in the form of
        [id,x,y].
        
        This function works differently whether u is a leaf node or not.
        """
        if u.isLeaf():
            u.dataPoints+=[p]
            #The next line is because we have to update the MBR so it includes the new data points.
            u.MBR=create_MBR_from_data_points(u.dataPoints)
            #After the insertion, if u overflows, we use the function handle_overflow on u.
            if u.length() > self.B:
                self.handle_overflow(u)
        else:
            #The subtree that should be chosen to insert node
            v = self.choose_subtree(u,p)
            #Insert the points into the subtree
            self.insert(v,p)
            #Then we update the MBR associated with the node u
            listMBR=[]
            for child in u.children:
                listMBR+=[child.MBR]
            u.MBR=create_MBR_from_MBRs(listMBR)

    def handle_overflow(self,u):
        """
        Decides how an overflowed situation is handled.
        
        Here, 4 different situations, in the order of the code:
        - If u is a leaf and the root (this situation occurs at the beginning when the Rtree has only one node.)
        - If u is a leaf and not the root
        - If u is not a leaf and is the root
        - If u isn't a leaf and isn't the root
        """
        if u.isLeaf():
            #The split function is different whether it is for a leaf or an internal node, that's why we need to separate the 2 cases.
            [S1,S2]=self.split_leaf(u)
            #Here, S1 and S2 are lists of data points.
            if u.isRoot():
                #We create 2 child leaf nodes for u, and u stops being a leaf.
                v=Node(dataPoints=S1,parent=u)
                w=Node(dataPoints=S2,parent=u)
                u.dataPoints=[]
                u.children=[v,w]
                u.MBR=create_MBR_from_MBRs([v.MBR,w.MBR])
            else:
                #We split the data points into two nodes, u and its brother/sister v
                v=Node(dataPoints=S1,parent=u.parent)
                u.dataPoints=S2
                u.MBR=create_MBR_from_data_points(S2)
                u.parent.children+=[v]
                #If u's parent is overflowing, we handle it.
                if len(u.parent.children)>self.B:
                    self.handle_overflow(u.parent)
        else:
            #The split function is different whether it is for a leaf or an internal node, that's why we need to separate the 2 cases.
            [S1,S2]=self.split_internal_node(u)
            #Here, S1 and S2 are lists of children of u.
            if u.isRoot():
                #We create 2 child nodes for u.
                v=Node(children=S1,parent=u, dataPoints=[])
                w=Node(children=S2,parent=u, dataPoints=[])
                for child in u.children:
                    if child in S1:
                        child.parent = v
                    if child in S2:
                        child.parent = w
                u.children=[v,w]
                u.MBR=create_MBR_from_MBRs([v.MBR,w.MBR])
            else:
                v=Node(children=S1,parent=u.parent, dataPoints=[])
                #The parent of the child has to be updated to the new parent.
                for child in v.children:
                    child.parent = v
                u.children=S2
                listMBR = []
                for child in S2:
                    listMBR +=[child.MBR]
                u.MBR=create_MBR_from_MBRs(listMBR)
                u.parent.children+=[v]
                #If u's parent is overflowing, we handle it.
                if len(u.parent.children)>self.B:
                    self.handle_overflow(u.parent)

    def choose_subtree(self,u,p):
        """
        The principle of this function is to choose the best subtree (= the best child) of u for the data point p
        to be inserted in. For that, for each child of u, we calculate the increase in perimeter of the MBR of
        that child that the insertion of p into the child would imply. We choose the child that has the smallest
        increase in perimeter. The function returns that node.
        """
        DIP = {}
        #DIP=Dictionary of Increasings in Perimeter (too long to write...)
        for child in u.children:
            IP=0
            #Calculation of IP (Increasing in Perimeter)
            if p[1]<child.MBR.x1:
                IP+=2*(child.MBR.x1-p[1])
            if p[1]>child.MBR.x2:
                IP+=2*(p[1]-child.MBR.x2)
            if p[2]<child.MBR.y1:
                IP+=2*(child.MBR.y1-p[2])
            if p[2]>child.MBR.y2:
                IP+=2*(p[2]-child.MBR.y2)
            #We add the MBR and its corresponding IP to the dictionary.
            #We want to know if there are ties, that is why DIP[IP] returns
            #the list of child nodes that have the same increase in perimeter.
            if IP in DIP.keys():
                DIP[IP]+=[child]
            else:
                DIP[IP]=[child]
            
        minIP=min(DIP.keys())
        #If there is no tie:
        if len(DIP[minIP])==1:
            return DIP[minIP][0]
        #If there is a tie, we choose the child node with the smallest MBR in perimeter:
        else:
            DicPerimeters={}
            for node in DIP[minIP]:
                perimeter=2*(node.MBR.y2 - node.MBR.y1 + node.MBR.x2 - node.MBR.x1)
                DicPerimeters[perimeter]=node
            minPerimeter=min(DicPerimeters.keys())
            return DicPerimeters[minPerimeter]
        
        
    def split_leaf(self,u):
        """
        u is a leaf node that is overflowing, the aim is to split it in 2
        non-overflowing leaf nodes, by minimising the sum of the perimeters 
        of the two MBRs. The returned object is a list of 2 elements, 
        each element being a list of data points. These 2 elements form the split.
        
        We will not go through all the possible splits because it is not efficient.
        Instead, we take only the split that are done on the x-axis or on the y-axis
        (i.e. for example the 50% points with the smallest x-coordinates and the 50% 
        points with the highest x-coordinates). The split limits go from 0.4*B to m-0.4*B
        where m is the total number of data points (so there is not 10%/90% split for example).
        """
        sumPerimeter=float('inf')
        bestSplit=[]
        m=len(u.dataPoints)
        #Split on x axis
        lx=sorted(u.dataPoints,key=itemgetter(1))
        for i in range(int(round(0.4*self.B)+1),int(m-round(0.4*self.B))):
            S1=lx[0:i]
            S2=lx[i:m]
            MBR1=create_MBR_from_data_points(S1)
            MBR2=create_MBR_from_data_points(S2)
            if sumPerimeter > MBR1.perimeter() + MBR2.perimeter():
                sumPerimeter = MBR1.perimeter() + MBR2.perimeter()
                bestSplit=[S1,S2]
        #Split on y axis
        ly=sorted(u.dataPoints,key=itemgetter(2))
        for i in range(int(round(0.4*self.B)+1),int(m-round(0.4*self.B))):
            S1=ly[0:i]
            S2=ly[i:m]
            MBR1=create_MBR_from_data_points(S1)
            MBR2=create_MBR_from_data_points(S2)
            if sumPerimeter > MBR1.perimeter() + MBR2.perimeter():
                sumPerimeter = MBR1.perimeter() + MBR2.perimeter()
                bestSplit=[S1,S2]
        return bestSplit
    
    def split_internal_node(self,u):
        """
        u is an internal node that is overflowing, the aim is to split it into
        2 non-overflowing internal nodes, by minimising the sum of perimeters
        of the 2 MBRs. The returned object is a list of 2 elements, each element
        being a list of child nodes of u. These 2 elements form the split.
        
        We will not go through all the possible splits because it is not efficient.
        Instead, we take only the split that are done on the x1-axis, the x2-axis,
        the y1-axis or the y2-axis where x1, x2, y1, y2 are the coordinates defining the MBRs.
        (i.e. for example the 50% points with the smallest x1-coordinates and the 50% 
        points with the highest x1-coordinates). The split limits go from 0.4*B to m-0.4*B
        where m is the total number of data points (so there is not 10%/90% split for example).
        """
        listMBR=[]
        for child in u.children:
            MBR=[child.MBR,child.MBR.x1,child.MBR.x2,child.MBR.y1,child.MBR.y2]
            listMBR+=[MBR]
        sumPerimeter=float('inf')
        bestSplit=[]
        m=len(listMBR)
        #Split on x axis by x1 (left) coordinates
        lx1=sorted(listMBR,key=itemgetter(1))
        #math.ceil(0.4*self.B), m-math.ceil(0.4*self.B)+1
        for i in range(round(0.4*self.B)+1,m-round(0.4*self.B)):
            S1=lx1[0:i]
            S2=lx1[i:m]
            SS1=[]
            SS2=[]
            for mbr in S1:
                SS1+=[mbr[1:]]
            for mbr in S2:
                SS2+=[mbr[1:]]
            MBR1=create_MBR_from_data_points(SS1)
            MBR2=create_MBR_from_data_points(SS2)
            if sumPerimeter > MBR1.perimeter() + MBR2.perimeter():
                sumPerimeter = MBR1.perimeter() + MBR2.perimeter()
                bestSplit=[S1,S2]
        #Split on x axis by x2 (right) coordinates
        lx2=sorted(listMBR,key=itemgetter(2))
        for i in range(round(0.4*self.B)+1,m-round(0.4*self.B)):
            S1=lx2[0:i]
            S2=lx2[i:m]
            SS1=[]
            SS2=[]
            for mbr in S1:
                SS1+=[mbr[1:]]
            for mbr in S2:
                SS2+=[mbr[1:]]
            MBR1=create_MBR_from_data_points(SS1)
            MBR2=create_MBR_from_data_points(SS2)
            if sumPerimeter > MBR1.perimeter() + MBR2.perimeter():
                sumPerimeter = MBR1.perimeter() + MBR2.perimeter()
                bestSplit=[S1,S2]
        #Split on y axis by y1 (bottom) coordinates
        ly1=sorted(listMBR,key=itemgetter(3))
        for i in range(round(0.4*self.B)+1,m-round(0.4*self.B)):
            S1=ly1[0:i]
            S2=ly1[i:m]
            SS1=[]
            SS2=[]
            for mbr in S1:
                SS1+=[mbr[1:]]
            for mbr in S2:
                SS2+=[mbr[1:]]
            MBR1=create_MBR_from_data_points(SS1)
            MBR2=create_MBR_from_data_points(SS2)
            if sumPerimeter > MBR1.perimeter() + MBR2.perimeter():
                sumPerimeter = MBR1.perimeter() + MBR2.perimeter()
                bestSplit=[S1,S2]
        #Split on y axis by y2 (top) coordinates
        ly2=sorted(listMBR,key=itemgetter(4))
        for i in range(round(0.4*self.B)+1,m-round(0.4*self.B)):
            S1=ly2[0:i]
            S2=ly2[i:m]
            SS1=[]
            SS2=[]
            for mbr in S1:
                SS1+=[mbr[1:]]
            for mbr in S2:
                SS2+=[mbr[1:]]
            MBR1=create_MBR_from_data_points(SS1)
            MBR2=create_MBR_from_data_points(SS2)
            if sumPerimeter > MBR1.perimeter() + MBR2.perimeter():
                sumPerimeter = MBR1.perimeter() + MBR2.perimeter()
                bestSplit=[S1,S2]
        S1=bestSplit[0]
        S2=bestSplit[1]
        SSS1=[]
        SSS2=[]
        for mbr in S1:
            SSS1+=[mbr[0]]
        for mbr in S2:
            SSS2+=[mbr[0]]
        S10=[]
        S20=[]
        for child in u.children:
            if child.MBR in SSS1:
                S10+=[child]
            elif child.MBR in SSS2:
                S20+=[child]
            else:
                print("ERROR!!!!!!!!") #The child's MBR has to be either in S1 or S2
        bestSplit0=[S10,S20]
        return bestSplit0
    
    def show(self):
        """
        Just displays information about the RTree, used to test the code only.
        """
        print('This is the Rtree')
        print('Its Root is',self.rootNode.id)
        print('Lets check the root')
        self.rootNode.show()
            
        
class Node:
    """
    Each node has a list of children, where each children is a "Node", it also
    has a reference to the parent, also a "Node". Each node is also attached to a unique 
    MBR. Finally, leaf nodes (and only them) contains data points.    
    """
    
    nbNodes=0    
    
    def __init__(self, children=[], parent="null", dataPoints=[]):
        self.parent = parent        
        self.children = children     
        self.dataPoints = dataPoints
        Node.nbNodes+=1
        self.id=Node.nbNodes
        
        if len(dataPoints)!=0:
            self.MBR=create_MBR_from_data_points(dataPoints)
        elif len(children)!=0:
            listMBR=[]
            for child in children:
                listMBR+=[child.MBR]
            self.MBR=create_MBR_from_MBRs(listMBR)
        else:
            self.MBR="null"
    
    def isLeaf(self):
        """
        Return True if the node is a leaf node, returns False otherwise
        """
        return len(self.children)==0
    
    def isRoot(self):
        """
        Return True if the node is the Root, return False otherwise
        """
        return self.parent=="null"
    
    def length(self):
        """
        Allows to check whether the node is overflowing or not (if the result of the lenght
        is strictly higher than B)
        """
        if len(self.children)==0:
            return len(self.dataPoints)
        else:
            return len(self.children)
    
    def show(self):
        """
        Just displays information about the Node, used to test the code only.
        """
        print('This node id is:',self.id)
        print('This node is a leaf:',self.isLeaf(),'is a root:',self.isRoot())
        if self.parent!="null":
            print('Its parent is:',self.parent.id)
        else:
            print('it has no parent')
        if len(self.children)!=0:
            print('its children are:')
            for child in self.children:
                print(child.id)
        else:
            print('it has no children')
        if len(self.dataPoints)!=0:
            print('its dataPoints are:')
            for point in self.dataPoints:
                print(point)
        else:
            print('it has no dataPoint')
        print('its MBR is:')
        print('x1=',self.MBR.x1)
        print('x2=',self.MBR.x2)
        print('y1=',self.MBR.y1)
        print('y2=',self.MBR.y2)
        
        for child in self.children:
            child.show()
            


class IncreasingSortedList:
    """
    This object is used for the Nearest Neighbour Search only.
    It is an ordered list (or a priority queue, same principle)
    The elements are sorted in a non-decreasing order.
    """
    def __init__(self, parameter=0):
        self.list=[]
        self.parameter=parameter
        
    def insert(self,obj):
        i=0
        while i<len(self.list):
            if obj[self.parameter]<=self.list[i][self.parameter]:
                break
            else:
                i=i+1
        self.list=self.list[0:i]+[obj]+self.list[i:len(self.list)]
    
    def pop(self):
        obj = self.list[0]
        self.list=self.list[1:]
        return obj

    
'''----------------------------------------------------------------------------------------------------'''

"""
RANGE QUERY
"""
def rangeQuery(rectangle,tree):
    return rangeQueryNode(rectangle,tree.rootNode)

def rangeQueryNode(rectangle,u):
    numberPoints=0
    if u.isLeaf():
        for point in u.dataPoints:
            if rectangle.contains(point):
                numberPoints+=1
        return numberPoints
    else:
        for child in u.children:
            if rectangle.intersects(child.MBR):
                np=rangeQueryNode(rectangle,child)
                numberPoints+=np
        return numberPoints


def rangeQueryList(rectangle,array):
    numberPoints=0
    for point in array:
        if rectangle.contains(point):
            numberPoints+=1
    return numberPoints



'''----------------------------------------------------------------------------------------------------'''



"""
NEAREST NEIGHBOUR BEST FIRST SEARCH
"""
def dist(p1,p2):
    """
    Returns the euclidean distance between 2 points.
    """
    return ( (p1[0]-p2[0])**2 + (p1[1]-p2[1])**2 )**0.5

def NNList(pointsList,q):
    """
    This function is used for the nearest-neighbour search. 
    Takes as inputs a list of points and a point q and returns
    the list of nearest neighbours of q
    (The list has several elements when they all have the same smallest 
    distance to q)
    """
    NNs = [pointsList[0][0]]
    D = dist(q, pointsList[0][1:])
    for point in pointsList[1:]:
        if dist(q, point[1:]) == D:
            NNs+=[point[0]]
        elif dist(q,point[1:]) < D:
            D = dist(q, point[1:])
            NNs = [point[0]]
    return [NNs,D]
    

def NNBFS(tree,q):
    """
    NNBFS = Nearest Neighbours Best First Search
    Use the same principles as the algorithm described in the course.
    """
    NNlist=[]
    NNdist=float('inf')
    l=IncreasingSortedList(parameter=1)
    l.insert([tree.rootNode,minDist(q,tree.rootNode.MBR)])
    while NNdist>=l.list[0][1]:
        T=l.pop()
        node=T[0]
        if node.isLeaf():
            [NNs,D]=NNList(node.dataPoints,q)
            if D==NNdist:
                NNlist+=NNs
            elif D<NNdist:
                NNdist=D
                NNlist=NNs
        else:
            for child in node.children:
                l.insert([child,minDist(q,child.MBR)])
    return NNlist

def minDist(p,r):
    """
    p is a point, r is a rectangle/MBR.

    If point is to the left/right and top/bottom of the rectangle. Take the
    nearest from the point to the respective side of the rectangle it is
    located at.

    Returns the distance in the form of a Euclidean Distance.
    """
    if p[0]<r.x1:
        x=r.x1-p[0]
    elif p[0]>r.x2:
        x=p[0]-r.x2
    else:
        x=0
        
    if p[1]<r.y1:
        y=r.y1-p[1]
    elif p[1]>r.y2:
        y=p[1]-r.y2
    else:
        y=0
        
    return (x**2+y**2)**0.5
                

'''----------------------------------------------------------------------------------------------------'''
"""
FILE OPERATIONS
"""
def readFileAndInsert(file):
    try:
        fileHandler = open(file, "r")
        numPoints = int(fileHandler.readline().strip())
        finalArray = []
        #Read in from the file
        for line in fileHandler:
            pString = line.strip().split()
            for i in range(len(pString)):
                pString[i] = int(pString[i])
            finalArray.append(pString)
        #Create an RTree Structure where B=3
        T=RTree(B=3)
        for i in range(len(finalArray)):
            T.insert(T.rootNode, finalArray[i])
        return T, finalArray, True
    except:
        return None, None, False

def readRangeQuery(file):
    try:
        fileHandler = open(file, "r")
        finalArray = []
        for line in fileHandler:
            tempArray = []
            for i in (line.strip().split()):
                tempArray.append(int(i))
            finalArray.append(tempArray)
        return finalArray, True
    except:
        return None, False

def readNearestNeighbor(file):
    try:
        fileHandler = open(file, "r")
        finalArray = []
        for line in fileHandler:
            tempArray = []
            for i in (line.strip().split()):
                tempArray.append(int(i))
            finalArray.append(tempArray)
        return finalArray, True
    except:
        return None, False

def writeRangeQuery(results):
    try:
        fileHandler = open("rangeQueryResults.txt", "w+")
        for line in results:
            fileHandler.write(str(line) + "\n")
        fileHandler.close()
    except:
        print("Writing of the range query file has been unsuccessful")

def writeNearestNeighbor(results):
    try:
        fileHandler = open("nearestNeighborResults.txt", "w+")
        for line in results:
            fileHandler.write(' '.join(str(x) for x in line) + "\n")
        fileHandler.close()
    except:
        print("Writing of the nearest neighbor file has been unsuccessful")

"""
MAIN FUNCTIONS
"""
while True:
    dataPointsText= input("Please enter the name of the text file: ")
    Tree, dataPointsArray, status = readFileAndInsert(dataPointsText)
    if status == True:
        print("Successful file read-in\n")
        break
    else:
        print("Invalid file, please try again\n")

while True:
    rangeQueryInput = input("Please enter the name of the range query file: ")
    listQuery, status =readRangeQuery(rangeQueryInput)
    if status == True:
        seqRangeQuery = []
        time0=time.clock()
        for query in listQuery:
            M=MBR(x1=query[0], x2=query[1], y1=query[2], y2=query[3])
            nb=rangeQueryList(M,dataPointsArray)
            seqRangeQuery += [nb]
        time1=time.clock()
        totalSequentialQueryScan=time1-time0
        averageSequentialQueryTime=totalSequentialQueryScan/len(listQuery)
        print("\nThe total time for sequential range query is: ", totalSequentialQueryScan, " seconds.")
        print("The average time for sequential range query is: ", averageSequentialQueryTime, " seconds.")

        queryRangeResults=[]
        time2=time.clock()
        for query in listQuery:
            M=MBR(x1=query[0], x2=query[1], y1=query[2], y2=query[3])
            np =rangeQuery(M,Tree)
            queryRangeResults+=[np]
        time3=time.clock()
        totalQueryRangeTime=time3-time2
        averageQueryRangeTime=totalQueryRangeTime/len(listQuery)
        print("The total time for R-Tree range query is: ", totalQueryRangeTime, " seconds.")
        print("The average time for R-Tree range query is: ", averageQueryRangeTime, " seconds.")
        print("The speedup is: ", totalSequentialQueryScan/totalQueryRangeTime, "\n")

        writeRangeQuery(queryRangeResults)

        break
    else:
        print("Invalid file, please try again\n")
    
while True:
    NNInput = input("Please enter the name of the nearest neighbor file: ")
    NNArray, status =readNearestNeighbor(NNInput)
    if status == True:
        NNQuery = []
        time0bis=time.clock()
        for point in NNArray:
            NNQuery+=NNList(dataPointsArray,point)[0]
        time1bis=time.clock()
        totalSequentialNNScan=time1bis-time0bis
        averageSequentialNNTime=totalSequentialNNScan/len(NNArray)
        print("\nThe total time for sequential nearest neighbor query is: ", totalSequentialNNScan, " seconds.")
        print("The average time for sequential nearest neighbor query is: ", averageSequentialNNTime, " seconds.")

        NNResults=[]
        time2bis=time.clock()
        for point in NNArray:
            NNResults+=[NNBFS(Tree,point)]
        time3bis=time.clock()
        totalNNTime=time3bis-time2bis
        averageNNTime=totalNNTime/len(NNArray)
        print("The total time for r-tree nearest neighbor query is: ", totalNNTime, " seconds.")
        print("The average time for r-tree Nearest Neighbor range query: ", averageNNTime, " seconds.")
        print("The speedup is: ", averageSequentialNNTime/averageNNTime)

        writeNearestNeighbor(NNResults)
        
        break
    else:
        print("Invalid file, please try again\n")
